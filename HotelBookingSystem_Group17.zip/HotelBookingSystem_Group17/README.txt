Hotel Booking System important info

connection string to DB was made to work on our pc's please change to access the .mdf file in the bin folder on your pc. We had major errors when trying to compute it to work for all pc's. (Please be understanding)

"Guests" and "Clients" are used interchangeably, as well as "Booking" and "Reservations".

We've filled our DB with test data that all work correctly according to all tests that have been run, and made use of proper validation to ensure "bad data" does not compromise the integrity of the database

In order to access our system please login using:
Username: Micah
Password: rtfmic002

Our system functionality includes:
	able to Add and Search Clients
	able to Add/View/Edit/Delete Bookings
	Generate a occupancy report for bookings
	Generate a expected monthly revenue report for up to 3 months in the future based off current bookings for then (its a cool line 	graph)
