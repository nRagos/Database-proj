﻿UPDATE [dbo].[Reservations]
SET [Complete] = 1
WHERE [ReservationID] = 1;
