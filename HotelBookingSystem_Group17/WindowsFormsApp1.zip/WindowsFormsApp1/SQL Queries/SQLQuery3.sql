﻿alter table dbo.Rooms
drop column Available