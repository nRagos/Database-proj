﻿CREATE TABLE [dbo].[Rooms] (
    [RoomID] NVARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([RoomID] ASC)
);
